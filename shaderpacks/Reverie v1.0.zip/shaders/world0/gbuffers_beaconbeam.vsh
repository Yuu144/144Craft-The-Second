#version 460 compatibility
#define DIMENSION_OVERWORLD

#include "/program/gbuffers_beaconbeam.vsh"