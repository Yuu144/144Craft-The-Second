#version 460 compatibility
#define DIMENSION_OVERWORLD

#include "/program/composite2.fsh"