#version 460 compatibility
#define DIMENSION_OVERWORLD

#include "/program/composite13.fsh"