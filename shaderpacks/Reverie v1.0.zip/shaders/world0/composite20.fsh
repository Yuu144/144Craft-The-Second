#version 460 compatibility
#define DIMENSION_OVERWORLD

#include "/program/composite20.fsh"