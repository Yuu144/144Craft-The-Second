#include "/generic/gtao.glsl"

vec3 filter_floodfill(sampler3D Sampler, vec3 FragPos) {
    vec3 Pos = FragPos / voxelDistance / vec3(2, 1, 2); 
    vec3 C = texture(Sampler, Pos).rgb; // Center

    return sqrt(C);
}

vec3 calc_lighting(Positions Pos, MaterialProperties Mat, bool IsDH, vec2 texcoord, bool IsHand, out vec4 ShadowBuf) {

    float NdotL;
    if (Mat.Id >= MATERIAL_TALL_PLANT_LOWER && Mat.Id <= MATERIAL_SHORT_PLANT) {
        NdotL = dot(sLightPosN, gbufferModelView[1].xyz);
    } else {
        NdotL = dot(sLightPosN, Mat.Normal);
    }

    Mat.Lightmap = pow4(Mat.Lightmap);

    if(IsHand)
        NdotL *= Mat.Lightmap.y;
    
    vec3 LMColor = TorchlightColor;
    #if (defined COLORED_LIGHTS) && (!defined DH_TERRAIN) && (!defined VOXY_TERRAIN)
        vec3 PlayerPosAbs = get_voxel_pos(Pos.Player) + view_player(Mat.Normal, false) * 0.065;

        if(is_in_voxel_range(PlayerPosAbs)) {
            vec3 VoxelData;
            if(frameCounter % 2 == 1) {
                VoxelData = filter_floodfill(voxelImgSampler_a, PlayerPosAbs);
            } else {
                VoxelData = filter_floodfill(voxelImgSampler_b, PlayerPosAbs);
            }
            VoxelData *= 12;

            float Fade = shadow_fade(Pos.Player * vec3(1,2,1), voxelDistance);
            LMColor = mix(VoxelData.rgb, LMColor, Fade);
        }
    #endif
    
    #ifdef DEFERRED
        #ifdef INDIRECT_LIGHTING
            vec3 _BentNormalEncoded;
            if(IsHand) {
                GIDenoise = vec4(0, 0, 0, 0);
                PixelAge.y = 1.0/255.0;
            } else {
                vec4 GICurrent = gi_bilateral_upscale(gl_FragCoord.xy, Mat.Normal, Pos.Screen.z, _BentNormalEncoded, IsDH);
                GIDenoise = temporal_denoise_gi(GICurrent, Pos.Screen, gl_FragCoord.xy, IsDH, PixelAge);
            }
        #endif
    #endif

    vec3 BentNormal = 
        #if AO_MODE == 2 && (defined DEFERRED)
            !IsHand ? _BentNormalEncoded: 
        #endif
            Mat.Normal;

    // Ambient lighting
    #ifdef DIMENSION_OVERWORLD
        float NangUp = dot(gbufferModelView[1].xyz, BentNormal) * 0.5 + 0.5;
        float NangL = -view_player(BentNormal, true).x * 0.5 + 0.5;
        vec3 SunA = texture_rgbm(atm_imageSampler, coords_ambient(vec2(NangL, NangUp))).rgb; 

        if(lightningBoltPosition.w > 0) {
            float VdotLi = 1 - min(1, distance(lightningBoltPosition.xz, Pos.Player.xz) * 0.0025);
            vec3 LiBPN = normalize((player_view(lightningBoltPosition.xyz, false) - Pos.View));
            float NdotLi = max(0, dot(Mat.Normal, LiBPN)) * 0.8 + 0.2;
            SunA += vec3(1) * NdotLi * pow4(VdotLi);
        }
        
        SunA = mix(MinLight, SunA, Mat.Lightmap.y);
    #elif defined DIMENSION_NETHER
        // Fake lighting, to make things look less flat
        float NdotU = clamp(dot(BentNormal, gbufferModelView[1].xyz), -1, 1);
        vec3 FakeLavaLight = TorchlightColor * c_NETHER_LAVA_ILLUMINATION * (-NdotU * 0.5 + 0.5);
        vec3 FakeAmbientLight = fogColor.rgb / get_luminance(fogColor.rgb) * c_NETHER_AMBIENT_ILLUMINATION * (NdotU * 0.5 + 0.5);
        vec3 SunA = FakeAmbientLight + FakeLavaLight;
        SunA *= 0.1 * c_NETHER_BRIGHTNESS;
    #elif defined DIMENSION_END
        vec3 SunA = srgb_rec2020(vec3(0.2, 0.1, 0.15));
    #else
        vec3 SunA = max(MinLight, 4 * srgb_rec2020(fogColor.rgb));
    #endif

    SunA += LMColor * Mat.Lightmap.x;
    SunA += Mat.Emissiveness * float(Mat.Emissiveness < 1);
    // Ao
    #if AO_MODE == 2 && (defined DEFERRED)
        SunA *= 1 - GIDenoise.a;
    #elif AO_MODE == 1
        SunA *= 1 - ssao(Mat.Normal, Pos.View, IsDH);
    #endif

    vec3 OutColor = SunA;

    #if (defined RSM) && (defined DIMENSION_OVERWORLD) && (defined DEFERRED)
        OutColor.rgb += GIDenoise.rgb;
    #endif

    float SSSS = Mat.SSS;
    // float SSSS = Mat.Lightmap.y > 0.1 ? Mat.SSS : 0;
    if (Mat.SSS <= 64.0 / 255.0) {
        if (Mat.Id == MATERIAL_SSS_WEAK) SSSS = SSS_STRENGTH_WEAK;
        else if (Mat.Id >= MATERIAL_SSS_STRONG && Mat.Id <= MATERIAL_LEAVES) SSSS = SSS_STRENGTH_STRONG;
        else SSSS = 0;

        float Porosity = Mat.SSS * 255.0 / 64.0;
        Mat.Albedo *= 1 - Porosity * 0.66 * Mat.Lightmap.y * wetness;
    }
    #ifdef DIMENSION_OVERWORLD
        bool DoSSS = SSSS > 0;
    #else
        bool DoSSS = false;
    #endif

    OutColor *= Mat.Albedo;

    vec3 SunDirect = vec3(0);
    vec3 Shadow = vec3(0);
    if (NdotL > 0 || DoSSS) {
        float _BlockerDist, _ShadowFade, _CloudShadow;
        Shadow = get_shadow(Pos.Player, Pos.View, IsDH, Mat.FlatNormal, Mat.Lightmap.y, DoSSS, _BlockerDist, _ShadowFade, _CloudShadow, ivec2(gl_FragCoord.xy));

        if (Shadow != vec3(0) || DoSSS) {
            vec3 LightColor;
            if (sunAngle < 0.5)
                LightColor = dataBuf.SunColor;
            else
                LightColor = dataBuf.MoonColor;

            float LHeight = sin(sunAngle * TAU); // to_player_pos(sunPosN).y;
            LightColor *= smoothstep(0.0, 0.05, abs(LHeight));

            SunDirect = Mat.Albedo / PI;
            SunDirect *= LightColor * max(NdotL, 0) * Shadow;

            if (DoSSS) {
                SSSS = max(1, (1 - SSSS) * 5);

                float Phase = max(ISOTROPIC_PHASE, cs_phase(dot(Pos.ViewN, sLightPosN), 0.6));
                vec3 SSS = exp(-SSSS * abs(NdotL)) * Shadow; // Simple SSS, from shadow blur or ss shadows
                #if SHADOW_FILTER == 2
                    float SSSFancy = exp(-SSSS * _BlockerDist) * _CloudShadow; // SSS from PCSS
                    SSS = mix(vec3(SSSFancy), SSS, _ShadowFade);
                #endif
                SunDirect += Mat.Albedo.rgb * LightColor * SSS * Phase;
            }
        }
    }
    OutColor += SunDirect;

    ShadowBuf.r = get_luminance(Shadow);
    ShadowBuf.gba = vec3(0);

    return OutColor * max(0.1, float(Mat.F0 < 230.0 / 255.0));
}
