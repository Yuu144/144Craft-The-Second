#version 460 compatibility
#define DIMENSION_END

#include "/program/composite4.vsh"
