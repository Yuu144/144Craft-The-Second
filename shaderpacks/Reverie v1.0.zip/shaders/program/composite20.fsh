#include "/lib/all_the_libs.glsl"

noperspective in vec2 texcoord;
noperspective in vec2 BloomTilePos;

#include "/generic/post/bloom.glsl"

/* RENDERTARGETS:0,10 */
layout(location = 0) out vec4 Color;
layout(location = 1) out vec4 BloomClear;

void main() {
    Color = texture(colortex0, texcoord);

    #ifdef BLOOM
    float Offset = 0;
    vec3 FinalBloom = blur3x3(colortex10, BloomTilePos).rgb;

    float WeatherColor = texture(colortex5, texcoord).g * 0.5;

    Color.rgb += FinalBloom * (BLOOM_STRENGTH + float(isEyeInWater == 1) + 0.2 * (rainStrength * isOutdoorsSmooth) + WeatherColor);
    #endif

    BloomClear = vec4(0); // Clear here because glClear is bugged on mesa(?)
}
