#include "/lib/all_the_libs.glsl"
#include "/generic/post/taa.glsl"
noperspective in vec2 texcoord;

/* RENDERTARGETS:0,4,8 */
layout(location = 0) out vec4 Color;
layout(location = 1) out vec4 TAAData;
layout(location = 2) out vec4 PrevDepth;

void main() {
    Color = texture(colortex0, texcoord);

    #ifndef DEBUG_DISABLE_TEMPORAL
    TAAData.rgb = TAA(Color.rgb, ivec2(gl_FragCoord.xy), texcoord);
    Color.rgb = TAAData.rgb;
    TAAData = RGBMEncode(TAAData.rgb);
    #endif

    bool IsDH;
    PrevDepth.r = get_depth(texcoord, IsDH);
    PrevDepth.r *= IsDH ? -1 : 1;
    PrevDepth.g = texture(depthtex1, texcoord).r;


    #if AA_MODE == 1
        Color.rgb = pow(Color.rgb, vec3(1/2.2));
    #endif
}
