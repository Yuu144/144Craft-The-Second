#include "/lib/all_the_libs.glsl"
#include "/generic/water.glsl"
attribute vec2 mc_Entity;
attribute vec2 mc_midTexCoord;
attribute vec4 at_midBlock;

noperspective out vec2 texcoord;
noperspective out vec4 glcolor;
noperspective out vec3 PlayerPos;

flat out vec3 Normal;
flat out float Material;


void main() {
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	glcolor = gl_Color;

	Normal = normalize(gl_NormalMatrix * gl_Normal);
	Material = (mc_Entity.x - 10000.0);

	gl_Position = ftransform();
	
	gl_Position.xyz = distort(gl_Position.xyz);

	#ifdef COLORED_LIGHTS
        if(renderStage == MC_RENDER_STAGE_TERRAIN_TRANSLUCENT) {
            if(gl_VertexID % 4 == 0 && at_midBlock.w > 0.1) {
                vec3 MidPos = gl_Vertex.xyz + at_midBlock.xyz / 64.0;
                vec3 PlayerMidPos = (shadowModelViewInverse * vec4((gl_ModelViewMatrix * vec4(MidPos, 1)).xyz, 1)).xyz;
                ivec3 PlayerPosAbs = ivec3(get_voxel_pos(PlayerMidPos));
                if(is_in_voxel_range(PlayerPosAbs)) {
                    vec4 Color = textureLod(gtexture, mc_midTexCoord, 4);
                    
                    Color.rgb = hardcoded_light_colors(Material, Color.rgb); 
                    Color.rgb *= max(0, (at_midBlock.w - 0.5) / 15);
                    Color.rgb = pow2(Color.rgb);
                    if(frameCounter % 2 == 1) {
                        imageStore(voxelImg_a, PlayerPosAbs, vec4(Color.rgb, 0));
                    } else {
                        imageStore(voxelImg_b, PlayerPosAbs, vec4(Color.rgb, 0));
                    }
                }
            }
        }
    #endif
}
