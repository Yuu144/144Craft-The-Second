#include "/lib/all_the_libs.glsl"
#include "/generic/water.glsl"
noperspective in vec2 texcoord;
noperspective in vec4 glcolor;
noperspective in vec3 PlayerPos;

flat in vec3 Normal;
flat in float Material;


#ifdef RSM
    /* RENDERTARGETS:0,1 */
#else
    /* RENDERTARGETS:0 */
#endif
layout(location = 0) out vec4 Color;
#ifdef RSM
    layout(location = 1) out vec4 ShadowNormal;
#endif

void main() {
    Color = texture(gtexture, texcoord) * glcolor;
    if (Color.a < 0.1) {
        discard;
        return;
    }

    if (renderStage == MC_RENDER_STAGE_ENTITIES) { // Stop entities from contributing to RSM because it ruins temporal stability
        Color.rgb = vec3(0);
    } 

    Color.rgb = srgb_rec2020(Color.rgb);

    #ifdef RSM
        ShadowNormal.rg = encodeUnitVector(Normal) * 0.5 + 0.5;
    #endif
}
