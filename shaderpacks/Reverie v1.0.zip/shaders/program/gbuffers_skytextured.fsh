void main() {
    discard;
}
