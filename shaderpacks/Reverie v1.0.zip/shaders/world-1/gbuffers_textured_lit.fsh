#version 460 compatibility
#define DIMENSION_NETHER

#include "/program/gbuffers_textured_lit.fsh"