#version 460 compatibility
#define DIMENSION_NETHER

#include "/program/gbuffers_armor_glint.fsh"