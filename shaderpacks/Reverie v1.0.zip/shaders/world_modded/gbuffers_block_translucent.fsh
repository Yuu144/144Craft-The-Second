#version 460 compatibility
#define DIMENSION_GENERIC

#include "/program/gbuffers_block_translucent.fsh"
