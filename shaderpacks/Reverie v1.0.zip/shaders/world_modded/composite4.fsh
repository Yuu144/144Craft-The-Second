#version 460 compatibility
#define DIMENSION_GENERIC

#include "/program/composite4.fsh"
