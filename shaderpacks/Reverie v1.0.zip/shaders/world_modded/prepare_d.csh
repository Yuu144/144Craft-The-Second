#version 460 compatibility
#define DIMENSION_GENERIC

#include "/program/prepare_d.csh"
