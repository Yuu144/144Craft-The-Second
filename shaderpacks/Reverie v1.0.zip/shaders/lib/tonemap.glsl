float get_luminance(vec3 x) {
    return dot(x, vec3(0.2126, 0.7152, 0.0722));
}

float get_luminance_rec2020(vec3 x) {
    return dot(x, vec3(0.2627, 0.6780, 0.0593));
}

vec3 reinhard(vec3 x) {
    return x / (1 + x);
}

vec3 reinhard_inv(vec3 x) {
    return x / (1 - x);
}

float reinhard(float x) {
    return x / (1 + x);
}

float reinhard_inv(float x) {
    return x / (1 - x);
}

#include "tonemap/Reinhard_Jodie.glsl"
#include "tonemap/ACES.glsl"
#include "tonemap/Uncharted2.glsl"
#include "tonemap/agx_minimal.glsl"

vec3 apply_tonemap(vec3 x) {
    #if TONEMAP_OPERATOR == 0
    return reinhard_jodie(x);
    #elif TONEMAP_OPERATOR == 1
    return ACESFitted(x);
    #elif TONEMAP_OPERATOR == 2
    return uncharted2_filmic(x);
    #elif TONEMAP_OPERATOR == 3
    return agx_tonemapping(x);
    #else
    return x;
    #endif
}

vec3 apply_saturation(vec3 Color, float Sat) {
    float luminance = get_luminance(Color);
    return mix(vec3(luminance), Color, Sat);
}

vec3 apply_vibrance(vec3 color, float intensity) {
    float mn = min(color.r, min(color.g, color.b));
    float mx = max(color.r, max(color.g, color.b));
    float sat = (1.0 - clamp(mx - mn, 0, 1)) * clamp(1.0 - mx, 0, 1) * get_luminance(color) * 5.0;
    vec3 lightness = vec3((mn + mx) * 0.5);

    return mix(color, mix(lightness, color, intensity), sat);
}

vec3 apply_contrast(vec3 color, float contrast) {
    return (color - 0.5) * contrast + 0.5;
}

vec3 purkinje_effect(vec3 Color) {
    vec3 ColorXYZ = rgb_to_xyz(Color * REC2020_REC709);
    float ScotopicLuminance = ColorXYZ.y * (1.33 * (1.0 + (ColorXYZ.y + ColorXYZ.z) / (ColorXYZ.x + 0.0001)) - 1.68);
    vec3 NightColor = ScotopicLuminance * PurkinjeTint;

    float BlendFactor = 1 - smoothstep(0.0, 0.05, ScotopicLuminance);
    // if(BlendFactor > 0.001) return vec3(0,0,1);
    vec3 FinalColor = mix(Color, NightColor, PURKINJE_EFFECT_STRENGTH * BlendFactor);
    return FinalColor;
}

vec3 film_grain(vec3 Color, vec2 Pos) {
    const float SIZE = 1.0 / (512 * FILM_GRAIN_SIZE);
    float framemod60 = float(int(frameTimeCounter * 60) % 600); // Grain becomes less apparent at high fps without this
    vec3 GrainColor = (texture(noisetex, fract(Pos.xy * SIZE + framemod60 * 1.61)).rgb - 0.5) * FILM_GRAIN_STRENGTH * 0.1;
    float BlendFactor = 1 - smoothstep(0.0, FILM_GRAIN_MAX_BRIGHTNESS, get_luminance(Color));
    return Color + GrainColor * BlendFactor;
}

vec3 decode_lut(vec3 Color, vec2 FragCoord) {
    float TexSize = textureSize(lutTexture, 0).x;
    float CellNr = pow(TexSize, 1/3.0);

    Color.rgb = pow(Color, vec3(1/2.2));
    Color += (dither(FragCoord.xy, false) - 0.5) / pow2(CellNr); 
    Color = clamp(Color, 0.0001, 0.99999);

    float OffsetInCell = fract(Color.b * CellNr);
    vec2 CellOffset = vec2(floor(OffsetInCell * CellNr), floor(Color.b * CellNr));
    vec2 Offset = Color.rg / CellNr;

    vec3 LutColor = pow(texture(lutTexture, clamp(Offset + CellOffset / CellNr, 0.5 / TexSize, 1 - 0.5 / TexSize)).rgb, vec3(2.2));

    return LutColor;
}
