#version 120

#define OVERWORLD_SHADER
#define ENTITIES
#define BLOCKENTITIES

#include "/dimensions/clrwl_translucent.vsh"
