#version 400 compatibility
#define WORLD_OVERWORLD
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_SOLID
#define PROGRAM_SHADOW_BLOCK
#define PROGRAM_SHADOW_ENTITIES
#define fsh
#include "/program/clrwl_shadow.fsh"
